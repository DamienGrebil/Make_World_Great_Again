Template pour un jeu phaser disposant d'un niveau selection et de 3 niveaux.
Le tmeplate possèdé également la structure pour rassembler des fonctions dans un meme fichier et les importer dans d'autres fichiers
